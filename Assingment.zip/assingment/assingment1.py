# -*- coding: utf-8 -*-
"""
Created on Mon Aug 23 10:33:28 2021

@author: Admin
"""
import numpy as np
import matplotlib.pyplot as plt
from skimage import io as sckio
print("PRESS 0  FOR AERIAL     PICTURE")
print("PRESS 1  FOR 100-DOLLAR PICTURE")
print("PRESS 2  FOR CAMERAMAN  PICTURE")
print("PRESS 3  FOR CANCER     PICTURE")
print("PRESS 4  FOR DFT        PICTURE")
print("PRESS 5  FOR EINSTEIN   PICTURE")
print("PRESS 6  FOR HOUSE      PICTURE")
print("PRESS 7  FOR JETPLANE   PICTURE")
print("PRESS 8  FOR KIDNET     PICTURE")
print("PRESS 9  FOR LAKE       PICTURE")
print("PRESS 10 FOR LENA GRAY  PICTURE")
print("PRESS 11 FOR LENS       PICTURE")
print("PRESS 12 FOR LIVING-ROOM PICTURE")
print("PRESS 13 FOR MANDRIL     PICTURE")
print("PRESS 14 FOR PEPPERS     PICTURE")
print("PRESS 15 FOR POLEN       PICTURE")
print("PRESS 16 FOR SPINE       PICTURE")
print("PRESS 17 FOR WALKBRIDGE  PICTURE")
print("PRESS 18 FOR WOMAN BLONDE PICTURE")
print("PRESS 19 FOR WOMAN DARK   PICTURE")
print("PRESS 20 FOR X-RAY        PICTURE")

a = int(input('Enter the digit of desired pivture  : '))

if a==0:
    image=sckio.imread("Aerial.tif")
    plt.imshow(image,cmap="gray")
    plt.show()
    res=image
    
elif a==1:
    image1=sckio.imread("100-dollars.tif")
    plt.imshow(image1,cmap="gray")
    plt.show()
    res=image1
    
elif a==2:
    image2=sckio.imread("Cameraman.tif")
    plt.imshow(image2,cmap="gray")
    plt.show()
    res=image2
    
elif a==3:
    image3=sckio.imread("Cancer.tif")
    plt.imshow(image3,cmap="gray")
    plt.show()
    res=image3
    
elif a==4:
    image4=sckio.imread("DFT.tif")
    plt.imshow(image4,cmap="gray")
    plt.show()
    res=image4
    
elif a==5:
    image5=sckio.imread("Einstein.tif")
    plt.imshow(image5,cmap="gray")
    plt.show()
    res=image5
    
elif a==6:
    image6=sckio.imread("house.tif")
    plt.imshow(image6,cmap="gray")
    plt.show()
    res=image6
    
elif a==7:
    image7=sckio.imread("jetplane.tif")
    plt.imshow(image7,cmap="gray")
    plt.show()
    res=image7
    
elif a==8:
    image8=sckio.imread("Kidnet.tif")
    plt.imshow(image8,cmap="gray")
    plt.show()
    res=image8
    
elif a==9:
    image9=sckio.imread("lake.tif")
    plt.imshow(image9,cmap="gray")
    plt.show()
    res=image9
    
elif a==10:
    image10=sckio.imread("lena_gray_512.tif")
    plt.imshow(image10,cmap="gray")
    plt.show()
    res=image10
    
elif a==11:
    image11=sckio.imread("Lens.tif")
    plt.imshow(image11,cmap="gray")
    plt.show()
    res=image11
    
elif a==12:
    image12=sckio.imread("livingroom.tif")
    plt.imshow(image12,cmap="gray")
    plt.show()
    res=image12

elif a==13:
    image13=sckio.imread("mandril_gray.tif")
    plt.imshow(image13,cmap="gray")
    plt.show()
    res=image13
    
elif a==14:
    image14=sckio.imread("peppers_gray.tif")
    plt.imshow(image14,cmap="gray")
    plt.show()
    res=image14
    
elif a==15:
    image15=sckio.imread("Pollen.tif")
    plt.imshow(image15,cmap="gray")
    plt.show()
    res=image15
    
elif a==16:
    image16=sckio.imread("Spine.tif")
    plt.imshow(image16,cmap="gray")
    plt.show()
    res=image16
    
elif a==17:
    image17=sckio.imread("walkbridge.tif")
    plt.imshow(image17,cmap="gray")
    plt.show()
    res=image17
    
elif a==18:
    image18=sckio.imread("woman_blonde.tif")
    plt.imshow(image18,cmap="gray")
    plt.show()
    res=image18
    
elif a==19:
    image19=sckio.imread("woman_darkhair.tif")
    plt.imshow(image19,cmap="gray")
    plt.show()
    res=image19
    
elif a==20:
    image20=sckio.imread("XRay.tif")
    plt.imshow(image20,cmap="gray")
    plt.show()
    res=image20
    
else:
    print("WRONG INPUT ")
    
    
print("PRESS 0  FOR NEGATIVE                     PICTURE")
print("PRESS 1  FOR THRESHOLDING                 PICTURE")
print("PRESS 2  FOR IMAGE SCALING                PICTURE")
print("PRESS 3  FOR LOG TRANSFORMATION           PICTURE")
print("PRESS 4  FOR ANTI LOG                     PICTURE")
print("PRESS 5  FOR GAMMA CORRECTION             PICTURE")
print("PRESS 6  FOR PIECE WISE TRANSFORMATION    PICTURE")
print("PRESS 7  FOR GREY LEVEL SLICING           PICTURE")

b = int(input('Enter the number for desired operation  : '))
if b==0:
    result=res-255
    plt.imshow(result,cmap="gray")
    plt.show()
elif b==1:
    row, column = res.shape
    minimum=0
    maximum=255
    for i in range(row):
        for j in range(column):
            if res[row, column] >= minimum:
                res[column, row] = 0
            else:
                res[row, column] = 255
    plt.imshow(res,cmap="gray")
    plt.show()
    
elif b==2:
    c = int(input('Enter the SCALING FACTOR   : '))
    result=res * c
    plt.imshow(result,cmap="gray")
    plt.show()
    
elif b==3:
    x = 255 / np.log(1 + np.max(res))
    log_image = x * (np.log(res + 1))
    log_image = np.array(log_image, dtype = np.uint8)
    plt.imshow(log_image,cmap="gray")
    plt.show()
    
elif b==4:
    inverse_log=np.exp(255**1/255)-1
    inverse_log = np.array(inverse_log, dtype = np.uint8)
    plt.imshow(inverse_log,cmap="gray")
    plt.show()
    
elif b==5:
    for i in [0.1, 0.5, 1.2, 2.2]:
        gamma_corrected = np.array(255*(res / 255) ** i, dtype = 'uint8')
        plt.imshow(gamma_corrected,cmap="gray")
        plt.show()
        
    
elif b==6:
    r1 = 70
    s1 = 0
    r2 = 140
    s2 = 255
    def pixelVal(pix, r1, s1, r2, s2):
         if (0 <= pix and pix <= r1):
             return (s1 / r1)*pix
         elif (r1 < pix and pix <= r2):
             return ((s2 - s1)/(r2 - r1)) * (pix - r1) + s1
         else:
             return ((255 - s2)/(255 - r2)) * (pix - r2) + s2
    pixelVal_vec = np.vectorize(pixelVal)
    contrast_stretched = pixelVal_vec(res, r1, s1, r2, s2)
    plt.imshow(contrast_stretched,cmap="gray")
    plt.show()

  

elif b==7:
    row, column = res.shape
    img1 = np.zeros((row,column),dtype = 'uint8')
    min_range = 10
    max_range = 60
    for i in range(row):
        for j in range(column):
            if img1[i,j]>min_range and img1[i,j]<max_range: img1[i,j] = 255
            else: 
                img1[i,j] = 0
    plt.imshow(img1,cmap="gray")
    plt.show()
    
else:
    print("WRONG OUTPUT")
    

    
    
    

