#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Sep 13 09:02:56 2021

@author: ammarahmadfarid
"""
import numpy as np

def padding(origImg,kernelWidth,kernelHeight):

    if kernelWidth % 2 == 1:

        centerX = np.int(np.floor(kernelWidth/2)+1)

        centerY = np.int(np.floor(kernelHeight/2)+1)
        print(centerX,centerY)
    else:
        centerX = kernelWidth
        centerY = 1
    leftExtra = centerX - 1
    rightExtra = kernelWidth - centerX
    topExtra = centerY - 1
    bottomExtra = kernelHeight - centerY
    rows,cols=np.shape(origImg)
    rowss=np.uint(rows + topExtra + bottomExtra)
    colss=np.uint(cols + leftExtra + rightExtra)
    outImg=np.uint(np.zeros(shape = (rowss, colss)))
    rowStart = np.int(topExtra-1)##cahnging + to -
    rowEnd = np.int(rows + topExtra-1)
    colStart = np.int(leftExtra-1)
    colEnd = np.int(cols + leftExtra-1)
    print(rowStart,rowEnd)
    print(colStart,colEnd)


    outImg[rowStart:rowEnd, colStart:colEnd] = origImg
    return outImg,rowStart,rowEnd,colStart,colEnd



def slidingwindow(origImg,posY, posX, kernalWidth, kernalHeight):
    if ((kernalWidth%2) == 1):

        offsetX = np.int(np.floor(kernalWidth/2))
        offsetY = np.int(np.floor(kernalHeight/2))


        posY_offsetY1=np.int(posY - offsetY)+1

        posY_offsetY2=np.int(posY + offsetY)+2
        posX_offsetX1=np.int(posX - offsetX)+1


        posX_offsetX2=np.int(posX + offsetX)+2



        outWindow = origImg[posY_offsetY1:posY_offsetY2, posX_offsetX1:posX_offsetX2]
    else:
        offsetX = kernalWidth
        offsetY = 0
        outWindow = origImg[posY:posY + kernalHeight-1, posX - offsetX+1:posX]
    return outWindow

def erosion(origImg):
    kernalH=3;
    kernalW=3
    SElement=[[1,1,1],[1,1,1],[1,1,1]]
    paddingImage,rowStart,rowEnd,colStart,colEnd=paddedImage,rowStart,rowEnd,colStart,coLEndapadding(image,kernalH,kernalW)
    rows,cols = np.shape(paddedImage)
    outputImg=np.uint(np.zeros(shape=(rows,cols)))
    for i in range(rowStart, rowEndnd):
            for J in range(colStart, colEnd):
                window=slidingwindow(paddedInage,i,j,kernalH,kernalW)
                windowR,windowC=np.shape(window)
                multipliedenp.sum(np.mul(window,SElement))
                if (multiplied==kernalH*kernalW):
                    outputImg[1,J]=1
                else:
                  outputImg[1, j]=0
   
       return outputImg


def dailation(origImg):
    kernalH=3;
    kernalW=3
    SElement=[[1,1,1],[1,1,1],[1,1,1]]
    paddingImage,rowStart,rowEnd,colStart,colEnd=paddedImage,rowStart,rowEnd,colStart,coLEndapadding(image,kernalH,kernalW)
    rows,cols = np.shape(paddedImage)
    outputImg=np.uint(np.zeros(shape=(rows,cols)))
    for i in range(rowStart, rowEndnd):
            for J in range(colStart, colEnd):
                window=slidingwindow(paddedInage,i,j,kernalH,kernalW)
                windowR,windowC=np.shape(window)
                multipliedenp.sum(np.mul(window,SElement))
                if (multiplied==kernalH*kernalW):
                    outputImg[1,J]=0
                else:
                  outputImg[1, j]=1
   
   return outputImg


inage=skio,imread(*/Vplumes/SANDISK/PycharmPrejects/morp
pit. inshow (image, cmap=pray)
plt. show()
print(np, shape (image) )
image-image/255
ErodedImg=erosion(image)

plt.show(erodedimg)
