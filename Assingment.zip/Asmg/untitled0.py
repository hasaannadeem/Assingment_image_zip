

import matplotlib.pyplot as plt
from skimage  import io as sckio


from skimage.morphology import (square, rectangle, diamond,closing, cube,erosion,binary_opening,dilation)


image_name=("lines.jpg")
image=(image_name)
img = sckio.imread(image)
plt.imshow(img,cmap="gray")


plt. show()


se=square(3)

eimg=dilation(img,se)
plt.imshow(eimg,cmap="gray")