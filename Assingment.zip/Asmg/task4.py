import numpy as np
import matplotlib.pyplot as plt
from skimage import io as sckio
def padding(origImg,kernelWidth,kernelHeight):

    if kernelWidth % 2 == 1:

        centerX = np.int(np.floor(kernelWidth/2)+1)

        centerY = np.int(np.floor(kernelHeight/2)+1)
        print(centerX,centerY)
    else:
        centerX = kernelWidth
        centerY = 1
    leftExtra = centerX - 1
    rightExtra = kernelWidth - centerX
    topExtra = centerY - 1
    bottomExtra = kernelHeight - centerY
    rows,cols=np.shape(origImg)
    rowss=np.uint(rows + topExtra + bottomExtra)
    colss=np.uint(cols + leftExtra + rightExtra)
    outImg=np.uint(np.zeros(shape = (rowss, colss)))
    rowStart = np.int(topExtra-1)##cahnging + to -
    rowEnd = np.int(rows + topExtra-1)
    colStart = np.int(leftExtra-1)
    colEnd = np.int(cols + leftExtra-1)
    print(rowStart,rowEnd)
    print(colStart,colEnd)


    outImg[rowStart:rowEnd, colStart:colEnd] = origImg
    return outImg,rowStart,rowEnd,colStart,colEnd



def slidingwindow(origImg,posY, posX, kernalWidth, kernalHeight):
    if ((kernalWidth%2) == 1):

        offsetX = np.int(np.floor(kernalWidth/2))
        offsetY = np.int(np.floor(kernalHeight/2))


        posY_offsetY1=np.int(posY - offsetY)+1

        posY_offsetY2=np.int(posY + offsetY)+2
        posX_offsetX1=np.int(posX - offsetX)+1


        posX_offsetX2=np.int(posX + offsetX)+2



        outWindow = origImg[posY_offsetY1:posY_offsetY2, posX_offsetX1:posX_offsetX2]







    else:
        offsetX = kernalWidth
        offsetY = 0
        outWindow = origImg[posY:posY + kernalHeight-1, posX - offsetX+1:posX]
    return outWindow
def erosion(image):
    kh=3
    kw=3
    se=[[1,1,1],[1,1,1],[1,1,1]]
    padimage,rowStart,rowEnd,colStart,colEnd=padding(image,kh,kw)
    row,col=np.shape(padimage)
    outputimage=np.uint(np.zeros(shape=(row,col)))
    for i in range (rowStart,rowEnd):
        for j in range(colStart,colEnd):
            window=slidingwindow(padimage,i,j,kh,kw)
            wr,wc=np.shape(window)
            multiply1=np.sum(np.multiply(window,se))
            if (multiply1==kh*kw):
                outputimage[i,j]=1
            else:
                outputimage[i,j]=0
    return outputimage
                    



def dilution(image):
    kh=3
    kw=3
    se=[[1,1,1],[1,1,1],[1,1,1]]
    padimage,rowStart,rowEnd,colStart,colEnd=padding(image,kh,kw)
    row,col=np.shape(padimage)
    outputimage=np.uint(np.zeros(shape=(row,col)))
    for i in range (rowStart,rowEnd):
        for j in range(colStart,colEnd):
            window=slidingwindow(padimage,i,j,kh,kw)
            wr,wc=np.shape(window)
            multiply1=np.sum(np.multiply(window,se))
            if (multiply1==kh*kw):
                outputimage[i,j]=0
            else:
                outputimage[i,j]=1
    return outputimage                               

def opening (image):
    eros=erosion(image)
    dil=dilution(eros)
    return dil
                   



def closing (image):
    dil=dilution(image)
    eros=erosion(dil)
    
    return eros
image=sckio.imread("holes.jpg")
plt.imshow(image,cmap="gray")
plt.show()


image2=closing(image)
plt.imshow(image2,cmap="gray")
plt.show()